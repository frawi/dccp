/* This file is auto generated, version 60 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#60 SMP Tue Jul 23 10:03:33 CEST 2019"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "frank-t470s"
#define LINUX_COMPILER "gcc version 8.3.0 (Ubuntu 8.3.0-6ubuntu1)"
