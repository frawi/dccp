#define UTS_RELEASE "4.15.0-55-generic"
#define UTS_UBUNTU_RELEASE_ABI 55
